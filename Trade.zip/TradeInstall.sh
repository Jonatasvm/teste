#! /bin/bash
sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
sudo apt-get update
sudo apt-get -y install postgresql
sudo apt-get -y install postgresql-plpython3-14
sudo apt-get -y install postgresql-contrib
sudo -u postgres psql -c "ALTER USER postgres WITH PASSWORD 'TESTE2';"
sudo -u postgres psql -c "create extension plpython3u;"

cd /etc/postgresql/14/main
exec sed -i.bkp "60c\listen_addresses aa= '*' " ./etc/postgresql/14/main/postgresql.conf
cd /etc/postgresql/14/main
exec sed -i '97a\host    all             all             0.0.0.0/0               scram-sha-256 '  ./pg_hba.conf
sudo service postgresql restart 

echo instalar extenção http

sudo apt-get -y install build-essential
sudo apt-get -y install postgresql-server-dev-14
sudo apt-get -y install libcurl4-openssl-dev
sudo apt-get -y install postgresql-contrib
sudo apt-get -y install unzip
cd /home
exec mdkir Tmp
cd /home/Tmp
exec wget https://github.com/pramsey/pgsql-http/archive/master.zip 
cd /home/Tmp
exec unzip master.zip
cd pgsql-http-master 
exec make && make install
sudo -u postgres psql -c "create extension http;"
sudo service postgresql restart